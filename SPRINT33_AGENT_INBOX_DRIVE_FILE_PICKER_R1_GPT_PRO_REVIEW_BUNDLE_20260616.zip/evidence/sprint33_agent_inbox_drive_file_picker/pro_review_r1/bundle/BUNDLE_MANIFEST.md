# Sprint 33 GPT Pro Review Bundle Manifest

Purpose: GPT Pro R1 gate review for `v0.11.21-agent-inbox-drive-file-picker-alpha`, replacing the failed `v0.11.20-agent-inbox-drive-picker-alpha` Agent Inbox Google Drive folder-selection flow.

## Bundle Contents

- Primary document: `PRIMARY_REVIEW_DOCUMENT.md`
- Current source files relevant to Drive authorization and Agent Inbox grant state:
  - `src/app-ui/GoogleDriveAuthorization.kt`
  - `src/app-ui/QualityAlternativeApp.kt`
  - `src/app-ui/MainViewModel.kt`
  - `src/domain/AgentInboxDrive.kt`
  - `src/domain/PreferencesSettingsRepository.kt`
- Tests:
  - `tests/GoogleDriveAuthorizationTest.kt`
  - `tests/GoogleDriveAuthorizationUiTest.kt`
- Product and process docs:
  - `docs/PRD.md`
  - `docs/AGENTS.md`
  - `docs/LANE_STATUS.md`
  - `docs/SPRINT_28_AGENT_INBOX_DRIVE_ACCESS.md`
  - `docs/SPRINT_29_AGENT_INBOX_FOLDER_SELECTOR.md`
  - `docs/AGENT_INBOX_PACKAGE_AUTHORING.md`
- Release gate evidence:
  - `docs/release-gate/*`
- Generated review aids:
  - `generated/diff_v0.11.20_to_v0.11.21_release_commit.patch`
  - `generated/diff_release_commit_to_current_head.patch`
  - `generated/github_release_view_v0.11.21.json`
  - `generated/current_head.txt`
  - `generated/release_tag_ref.txt`
  - `generated/superseded_tag_ref.txt`
  - `generated/git_status_before_review.txt`
  - `generated/bundle_file_list.txt`

## Curation Notes

This bundle intentionally excludes APK binaries, old root-level review bundles, historical screenshot folders, and unrelated sprint artifacts. The published APK digest and GitHub asset metadata are shipped instead of the APK binary itself.

The bundle is sufficient for a scoped code/release-evidence audit of the Sprint 33 authorization hotfix. It is not sufficient to prove live Google Drive Picker or rclone child visibility on a signed-in Android device.
