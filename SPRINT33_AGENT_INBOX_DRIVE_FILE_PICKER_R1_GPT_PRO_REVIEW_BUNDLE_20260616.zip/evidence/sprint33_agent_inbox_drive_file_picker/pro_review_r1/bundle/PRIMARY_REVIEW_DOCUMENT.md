# Sprint 33 Agent Inbox Drive File Picker Hotfix - Primary Review Document

## Review Target

Review the published Sprint 33 hotfix `v0.11.21-agent-inbox-drive-file-picker-alpha` for the Agent Inbox Google Drive folder-selection failure reported on device.

The user reported that after `v0.11.20-agent-inbox-drive-picker-alpha`, Settings > Agent Inbox showed:

`Google Drive authorization hit a Google Play services error. Retry Google Drive connection.`

The failure happened before the folder could be selected.

## Intended Fix

Sprint 32 introduced a dedicated Agent Inbox readonly Google Picker mode that requested:

- `drive.readonly`
- Google Picker resource parameters:
  - `PICKER_OAUTH_TRIGGER=true`
  - `PICKER_ALLOW_FOLDER_SELECTION=true`
- consent prompt

Device feedback showed that Google Play Services rejected that combination with `INTERNAL_ERROR`.

Sprint 33 removes the dedicated readonly picker mode and routes Agent Inbox folder selection through the already-supported Google Picker request shape:

- `drive.file`
- `PICKER_OAUTH_TRIGGER=true`
- `PICKER_ALLOW_FOLDER_SELECTION=true`
- consent prompt
- extraction of `picked_file_ids`

The controlled `drive.readonly` path remains only for non-picker typed/manual folder-id scan/import flows. It must not be combined with picker resource parameters.

## Scope Boundaries

In scope:

- Does the published hotfix remove the authorization request shape that caused the on-device Play Services `INTERNAL_ERROR`?
- Does Agent Inbox folder selection now use the supported `drive.file` Picker request?
- Do legacy Google Drive document-tree Agent Inbox states and Google Drive-configured empty states route through that supported Picker request?
- Do tests and release evidence cover the changed authorization and UI-routing logic?
- Is the published release metadata, tag, APK version, SHA, and release gate evidence internally consistent?

Out of scope:

- Proving that `drive.file` Picker grants expose future rclone-added child packages. That remains a known device/live-Drive question unless the bundle proves it.
- Claiming connected visual/e2e success for Sprint 33. The release gate explicitly says it was not run because no Android device/emulator was available locally.
- Changing the package authoring contract. Sprint 33 does not change `manifest.json`, Markdown, EPUB, image sidecar, priority, or import validation rules.

## Canonical Evidence In This Bundle

- `generated/diff_v0.11.20_to_v0.11.21_release_commit.patch`
  - Main patch under review.
- `src/app-ui/GoogleDriveAuthorization.kt`
  - Canonical authorization mode/request builder.
- `src/app-ui/QualityAlternativeApp.kt`
  - UI routing for Agent Inbox folder selection, scan, and import authorization.
- `src/app-ui/MainViewModel.kt`
  - Grant-mode persistence and scan behavior.
- `src/domain/AgentInboxDrive.kt`
  - Grant-mode constants and Drive scope constants.
- `src/domain/PreferencesSettingsRepository.kt`
  - Persistent validation of Agent Inbox grant mode.
- `tests/GoogleDriveAuthorizationTest.kt`
  - Unit tests for authorization request shape.
- `tests/GoogleDriveAuthorizationUiTest.kt`
  - Unit tests for UI routing helpers and authorization error copy.
- `docs/PRD.md`
  - Product/privacy requirements. Especially FR3B and NFR Drive access constraints.
- `docs/LANE_STATUS.md`
  - Current sprint status and release publication record.
- `docs/release-gate/VALIDATION_SUMMARY.md`
  - Release gate summary.
- `docs/release-gate/final_gradle_build.log`
  - Full local Gradle gate output.
- `docs/release-gate/apk_debug_output_metadata.json`
  - APK version metadata.
- `docs/release-gate/apk_sha256.txt`
  - APK SHA-256.
- `generated/github_release_view_v0.11.21.json`
  - GitHub Release metadata and asset digests after publication.
- `generated/release_tag_ref.txt`
  - Local tag reference for `v0.11.21-agent-inbox-drive-file-picker-alpha`.

## Known Weakness To Treat Honestly

Connected visual/e2e was not run for Sprint 33. The local `adb devices -l` output had no attached device, and no local emulator binary was available in the standard SDK paths checked.

That is allowed to be a finding only if it materially blocks this scoped hotfix from being release-ready. Do not invent connected evidence that is not shipped. If this gap should prevent `10/10`, say so directly and explain the minimum proof required.

## Desired Review Standard

Give `SCORE: 10/10`, `VERDICT: PASS`, and `VISUAL REVIEW: NOT APPLICABLE` only if:

- the forbidden `drive.readonly` + Picker parameter request path is fully removed from production selection routing,
- readonly authorization remains available only without Picker parameters,
- the supported `drive.file` Picker path is the path used for Google Drive folder selection/reconnect states,
- release artifacts and metadata are internally consistent,
- no user-data/privacy regression is introduced,
- missing connected-device evidence is honestly documented and not a release blocker for this narrow authorization-request hotfix.

If any of those are not true, return a lower score and list exact blockers.
