# Sprint 21 R3 Bundle Manifest

## Review Scope

This R3 bundle is scoped to Sprint 21 fixes for:

- default portable profile backup restore after app reinstall / data clear,
- safe Settings restore flow with preview plus explicit Replace confirmation,
- meditation completion gong replacing previous beep tone,
- long EPUB/Markdown reading-time estimates no longer capped at 20 minutes.

## Included

- Product contract: `PRD.md`.
- Current change diff: `evidence/sprint21_profile_gong_reading_time/sprint21_current_diff.patch`.
- Sprint evidence and R1 review trail: `evidence/sprint21_profile_gong_reading_time/**`.
- R2 review trail: `evidence/sprint21_profile_gong_reading_time/GPT_PRO_REVIEW_R2.md`.
- Build/config files: root/app Gradle files, Gradle wrapper files, version catalog, and Android manifests.
- Packaging files referenced by Gradle, including `app/proguard-rules.pro` and `app/schemas`.
- Full `app/src` source tree so referenced domain models, repositories, resources, fixtures, and tests are available for source audit.
- Profile backup/restore implementation and tests.
- Reading-time implementation, importer call-chain files, and tests.
- UI/ViewModel implementation and connected UI tests.
- Current unit/connected XML/logcat outputs.
- Current emulator screenshots for onboarding restore entry, Settings default-backup preview/confirmation/success, and meditation calm alternative.
- Current emulator screenshot for the completed meditation timer state after the gong copy appears.

## Excluded

- Historical root-level review bundles and release artifacts from previous sprints.
- Full build outputs except targeted XML/logcat evidence.
- Stale duplicate screenshot folders from previous Sprint 16/17/19 review packets; R3 keeps current Sprint 21 visual evidence under neutral screenshot directory names plus one manual onboarding entry screenshot.
- Duplicate raw harvest copies for R1/R2 after their text was copied into `GPT_PRO_REVIEW_R1.md` and `GPT_PRO_REVIEW_R2.md`.
