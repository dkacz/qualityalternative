# Sprint 21 R6 GPT Pro Review: Profile Restore, Gong, Reading Time

You are reviewing the shipped bundle only. Please perform an adversarial release-gate review for Sprint 21 R6.

Start by reading:

1. `evidence/sprint21_profile_gong_reading_time/BUNDLE_MANIFEST_R6.md`
2. `evidence/sprint21_profile_gong_reading_time/README.md`
3. `evidence/sprint21_profile_gong_reading_time/GPT_PRO_REVIEW_R1.md`
4. `evidence/sprint21_profile_gong_reading_time/GPT_PRO_REVIEW_R2.md`
5. `evidence/sprint21_profile_gong_reading_time/GPT_PRO_REVIEW_R3.md`
6. `evidence/sprint21_profile_gong_reading_time/GPT_PRO_REVIEW_R4.md`
7. `evidence/sprint21_profile_gong_reading_time/GPT_PRO_REVIEW_R5.md`
8. `evidence/sprint21_profile_gong_reading_time/sprint21_current_diff.patch`
9. The implementation and test files included in the bundle.

Primary product issues to verify:

- After app reinstall / clean state, the app can restore settings from the default shared portable profile backup path.
- The default profile backup path is user-visible and sane: `Downloads/Quality Alternative/quality-alternative-profile.json`.
- Settings `Restore default backup` is not destructive: it must show a preview first, must not mutate local settings before confirmation, and must require an explicit Replace confirmation before applying.
- Android MediaStore collision filenames such as `quality-alternative-profile (1).json` and timestamp collision names are handled so a matching newest backup can be restored.
- Meditation completion no longer uses a short beep/tone; it uses the generated in-app gong path. The connected test waits for a one-minute timer to complete and captures the completion state.
- Reading-time estimates for imported EPUB/Markdown documents use extracted document text and can represent multi-hour books, with a defensive 720-minute cap. Link/session defaults must remain short.

R1/R2/R3/R4/R5 recheck:

- R1 blocked because Settings default restore immediately applied replace. Verify that R6 still fixes this.
- R2 blocked because `DocumentReadingTimeEstimatorTest.kt` was stale and absent from unit XML. Verify that R6 still fixes this.
- R3 blocked because `DocumentImportCandidateFactoryTest.kt` was stale and absent from unit XML. Verify that R6 still fixes this and ships its XML.
- R4 passed functionally but scored 9/10 for package hygiene. Verify that R6 still fixes the R4 naming/hygiene issues and that the final connected logcat no longer contains stale selected-test names, stale current screenshot names, or the prior `Failed to build unique file` noise.
- R5 passed functionally but scored 9/10 because the bundle included duplicate raw harvest review copies. Verify that R6 no longer ships `pro_review_harvest_r4/`, `pro_review_harvest_r5/`, or byte-identical raw review duplicates, and that the canonical review trail is the named `GPT_PRO_REVIEW_R*.md` files.

Evidence to audit:

- Unit XML under `evidence/sprint21_profile_gong_reading_time/test-results/unit/`.
- Connected XML/logcat under `evidence/sprint21_profile_gong_reading_time/test-results/connected/`.
- Screenshots under `evidence/sprint21_profile_gong_reading_time/screenshots/current/` and `screenshots/manual/`, including `reading_time_import/14_long_document_import_multi_hour.png`.

Please also review package hygiene. Flag any stale, duplicated, misleading, missing, or noisy artifacts as `BUNDLE GAP` or `PACKAGE HYGIENE`.

Required response format:

SCORE: x/10
VERDICT: PASS | REVISE | BLOCK
VISUAL REVIEW: PASS | REVISE | BLOCK

BLOCKERS:
- ...

R1/R2/R3/R4/R5 RECHECK:
- ...

PROFILE RESTORE:
- ...

SETTINGS DEFAULT RESTORE SAFETY:
- ...

MEDIASTORE COLLISION:
- ...

MEDITATION GONG:
- ...

READING TIME:
- ...

TEST/EVIDENCE:
- ...

BUNDLE GAPS:
- ...

PACKAGE HYGIENE:
- ...

If everything is release-ready for this slice, give `SCORE: 10/10`, `VERDICT: PASS`, and `VISUAL REVIEW: PASS`.
