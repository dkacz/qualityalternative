# Sprint 21 R2 GPT Pro Review: Profile Restore, Gong, Reading Time

You are reviewing the shipped bundle only. Please perform an adversarial release-gate review for Sprint 21 R2.

Start by reading:

1. `evidence/sprint21_profile_gong_reading_time/BUNDLE_MANIFEST_R2.md`
2. `evidence/sprint21_profile_gong_reading_time/README.md`
3. `evidence/sprint21_profile_gong_reading_time/GPT_PRO_REVIEW_R1.md`
4. `evidence/sprint21_profile_gong_reading_time/sprint21_current_diff.patch`
5. The implementation and test files included in the bundle.

Primary product issues to verify:

- After app reinstall / clean state, the app can restore settings from the default shared portable profile backup path.
- The default profile backup path is user-visible and sane: `Downloads/Quality Alternative/quality-alternative-profile.json`.
- Settings `Restore default backup` is not destructive: it must show a preview first, must not mutate local settings before confirmation, and must require an explicit Replace confirmation before applying.
- Android MediaStore collision filenames such as `quality-alternative-profile (1).json` are handled so the newest matching default backup wins.
- Meditation completion no longer uses a short beep/tone; it uses the generated in-app gong path.
- Reading-time estimates for imported EPUB/Markdown documents use extracted document text and can represent multi-hour books, with a defensive 720-minute cap. Link/session defaults must remain short.

R1 blocker recheck:

- R1 blocked because Settings default restore immediately applied replace. Verify that R2 fixes this in `MainViewModel.kt`, `QualityAlternativeApp.kt`, and `MainActivityTest.kt`.

Evidence to audit:

- Unit XML under `evidence/sprint21_profile_gong_reading_time/test-results/unit/`.
- Connected XML/logcat under `evidence/sprint21_profile_gong_reading_time/test-results/connected/`.
- Screenshots under `evidence/sprint21_profile_gong_reading_time/screenshots/current/` and `screenshots/manual/`.

Please also review package hygiene. Flag any stale, duplicated, misleading, missing, or noisy artifacts as `BUNDLE GAP` or `PACKAGE HYGIENE`.

Required response format:

SCORE: x/10
VERDICT: PASS | REVISE | BLOCK
VISUAL REVIEW: PASS | REVISE | BLOCK

BLOCKERS:
- ...

R1 BLOCKER RECHECK:
- ...

PROFILE RESTORE:
- ...

SETTINGS DEFAULT RESTORE SAFETY:
- ...

MEDIASTORE COLLISION:
- ...

MEDITATION GONG:
- ...

READING TIME:
- ...

TEST/EVIDENCE:
- ...

BUNDLE GAPS:
- ...

PACKAGE HYGIENE:
- ...

If everything is release-ready for this slice, give `SCORE: 10/10`, `VERDICT: PASS`, and `VISUAL REVIEW: PASS`.
