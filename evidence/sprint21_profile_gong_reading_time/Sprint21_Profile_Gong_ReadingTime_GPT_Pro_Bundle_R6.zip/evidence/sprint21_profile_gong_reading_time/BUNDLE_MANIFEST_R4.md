# Sprint 21 R4 Bundle Manifest

## Review Scope

This R4 bundle is scoped to Sprint 21 fixes for:

- default portable profile backup restore after app reinstall / data clear,
- safe Settings restore flow with preview plus explicit Replace confirmation,
- meditation completion gong replacing previous beep tone,
- long EPUB/Markdown reading-time estimates no longer capped at 20 minutes.

## R4 Changes Since R3

- Fixed the R3 blocker: `DocumentImportCandidateFactoryTest` now covers the imported-document UI candidate path with 45-minute 10,000-word Markdown/EPUB estimates and 720-minute huge-document caps.
- Added `DocumentImportCandidateFactoryTest` XML to the unit evidence.
- Added connected visual evidence for a long Markdown import preview displaying `2 hr 15 min`.
- Renamed current Sprint 21 screenshot output paths used by this slice so connected logcat no longer implies stale Sprint 16 profile-restore or Sprint 19 meditation evidence.
- Included `app/proguard-rules.pro` and `app/schemas`, which R3 identified as missing bundle-support files.

## Included

- Product contract: `PRD.md`.
- Current change diff: `evidence/sprint21_profile_gong_reading_time/sprint21_current_diff.patch`.
- Sprint evidence and R1/R2/R3 review trail: `evidence/sprint21_profile_gong_reading_time/**`, excluding ZIP archives.
- Build/config files: root/app Gradle files, Gradle wrapper files, version catalog, Android manifests, `app/proguard-rules.pro`, and `app/schemas`.
- Full `app/src` source tree so referenced domain models, repositories, resources, fixtures, and tests are available for source audit.
- Profile backup/restore implementation and tests.
- Reading-time implementation, importer call-chain files, and tests.
- UI/ViewModel implementation and connected UI tests.
- Current unit/connected XML/logcat outputs.
- Current emulator screenshots for onboarding restore entry, Settings default-backup preview/confirmation/success, meditation calm alternative, completed meditation-gong state, and long-document import preview.

## Excluded

- Historical root-level review bundles and release artifacts from previous sprints.
- ZIP bundles from earlier R1/R2/R3/R4 attempts; they are derivative of files already shipped in this packet.
- Full build outputs except targeted XML/logcat evidence.
- Stale duplicate screenshot folders from previous Sprint 16/17/19 review packets; R4 keeps current Sprint 21 visual evidence under neutral screenshot directory names plus one manual onboarding entry screenshot.
- Duplicate raw harvest copies after their text was copied into named `GPT_PRO_REVIEW_*.md` files.

## Known Evidence Boundary

- The default profile restore evidence proves clean-state/data-reset recovery from shared Downloads. The implementation stores the default backup outside app-private data, so it is designed to survive reinstall, but this packet does not include a literal uninstall/reinstall UI run.
- The MediaStore collision residue visible in logs is intentional verification residue from repeated runs. The connected collision test asserts that the newest inserted default backup wins.
- Historical R2/R3 review files quote old screenshot directory names and old test names because they are preserved as the audit trail. Current R4 connected logcat and current screenshots use the Sprint 21 paths/tests listed in this manifest.
