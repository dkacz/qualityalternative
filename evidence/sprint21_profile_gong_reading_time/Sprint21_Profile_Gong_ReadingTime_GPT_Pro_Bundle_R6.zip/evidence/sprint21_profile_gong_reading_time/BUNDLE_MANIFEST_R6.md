# Sprint 21 R6 Bundle Manifest

## Review Scope

This R6 bundle is scoped to Sprint 21 fixes for:

- default portable profile backup restore after app reinstall / data clear,
- safe Settings restore flow with preview plus explicit Replace confirmation,
- meditation completion gong replacing previous beep tone,
- long EPUB/Markdown reading-time estimates no longer capped at 20 minutes,
- package-hygiene cleanup after the R5 review.

## R6 Changes Since R5

- Preserved the R5 review as the canonical file `GPT_PRO_REVIEW_R5.md`.
- Removed duplicate raw harvest review copies from `pro_review_harvest_r4/` and `pro_review_harvest_r5/`; those directories are no longer shipped.
- R6 keeps the complete named review trail `GPT_PRO_REVIEW_R1.md` through `GPT_PRO_REVIEW_R5.md` without byte-identical raw harvest duplicates.

## Included

- Product contract: `PRD.md`.
- Current change diff: `evidence/sprint21_profile_gong_reading_time/sprint21_current_diff.patch`.
- Sprint evidence and R1/R2/R3/R4/R5 named review trail: `evidence/sprint21_profile_gong_reading_time/**`, excluding ZIP archives and raw harvest scratch directories.
- Build/config files: root/app Gradle files, Gradle wrapper files, version catalog, Android manifests, `app/proguard-rules.pro`, and `app/schemas`.
- Full `app/src` source tree so referenced domain models, repositories, resources, fixtures, and tests are available for source audit.
- Profile backup/restore implementation and tests.
- Reading-time implementation, importer call-chain files, and tests.
- UI/ViewModel implementation and connected UI tests.
- Current unit/connected XML/logcat outputs.
- Current emulator screenshots for onboarding restore entry, Settings default-backup preview/confirmation/success, meditation calm alternative, completed meditation-gong state, and long-document import preview.

## Excluded

- Historical root-level review bundles and release artifacts from previous sprints.
- ZIP bundles from earlier R1/R2/R3/R4/R5 attempts; they are derivative of files already shipped in this packet.
- Raw `pro_review_harvest_*` scratch directories after their text was copied into named `GPT_PRO_REVIEW_*.md` files.
- Full build outputs except targeted XML/logcat evidence.
- Stale duplicate screenshot folders from previous Sprint 16/17/19 review packets; R6 keeps current Sprint 21 visual evidence under neutral/current screenshot directory names plus one manual onboarding entry screenshot.

## Known Evidence Boundary

- The default profile restore evidence proves clean-state/data-reset recovery from shared Downloads. The implementation stores the default backup outside app-private data, so it is designed to survive reinstall, but this packet does not include a literal uninstall/reinstall UI run.
- The collision test intentionally creates duplicate-name MediaStore rows with a unique test filename and asserts that the newest inserted matching backup wins.
- Historical R2/R3/R4/R5 review files quote old screenshot directory names, old test names, prior package-hygiene findings, and prior bundle gaps because they are preserved as the audit trail. Current R6 connected logcat, current source helpers, current selected test names, current screenshots, and current bundle contents use the names listed in this manifest.
