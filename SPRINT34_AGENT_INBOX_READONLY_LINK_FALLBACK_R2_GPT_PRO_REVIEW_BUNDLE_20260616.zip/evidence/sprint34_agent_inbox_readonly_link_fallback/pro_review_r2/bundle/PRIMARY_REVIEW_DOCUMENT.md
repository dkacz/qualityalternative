# Sprint 34 Agent Inbox Readonly Link Fallback - Primary Review Document

## Review Target

Review `v0.11.22-agent-inbox-readonly-link-fallback-alpha`, the follow-up release after GPT Pro R1 rejected Sprint 33 with `SCORE: 8/10`, `VERDICT: REVISE`.

R1 is included at `prior-review/GPT_PRO_REVIEW_R1.md`.

## R1 Findings To Recheck

1. The typed/manual readonly folder-id connection path was documented as available, but no UI caller reached it.
2. The R1 bundle did not include literal source definitions for `ANNOTATION_DRIVE_SCOPE` and `AGENT_INBOX_DRIVE_READONLY_SCOPE`.
3. The R1 bundle omitted the concrete Drive client and Google Drive document-tree URI predicate, so privacy and routing claims were only partially auditable.
4. R1 noted stale code noise: an unreachable Google Drive document-tree branch after an early Picker redirect.

## Intended R2 Fixes

- Settings > Agent Inbox now exposes `Drive folder link or id` plus `Use Drive link` when no Agent Inbox folder is connected.
- That action calls `beginAgentInboxReadonlyFolderConnection()` and launches `AGENT_INBOX_CONNECT_READONLY`.
- `AGENT_INBOX_CONNECT_READONLY` requests `drive.readonly` with consent and without Picker resource parameters.
- `AGENT_INBOX_PICK_FOLDER` remains the supported Google Picker path using `drive.file` plus Picker folder resource parameters.
- Tests now assert literal OAuth scope strings:
  - `https://www.googleapis.com/auth/drive.file`
  - `https://www.googleapis.com/auth/drive.readonly`
- The stale unreachable post-persist Google Drive document-tree branch was removed.
- The R2 bundle includes the scope constants, Drive clients, Drive client tests, and URI predicate source.

## Current Release

- Release: `v0.11.22-agent-inbox-readonly-link-fallback-alpha`
- Release commit: `8c3d20e1858c125f96fa45c84282e6e3da0aed99`
- Release URL: `https://github.com/dkacz/qualityalternative/releases/tag/v0.11.22-agent-inbox-readonly-link-fallback-alpha`
- APK SHA-256: `2bd452f4b37b5e92fa203940096474da7d35b092bb820d306e19e1bc2c280264`
- APK metadata: `versionCode=38`, `versionName=0.11.22-alpha`

## Scope Boundaries

In scope:

- Verify R1 blocker closure.
- Verify picker path still uses `drive.file` and picker folder parameters.
- Verify readonly typed/manual path is reachable and uses readonly without picker parameters.
- Verify Drive scan requests are limited to selected/supplied folder parents and do not discover the user's whole Drive by name.
- Verify Google Drive document-tree reconnect routing no longer uses the fragile provider scan path.
- Verify release metadata and release gate evidence are internally consistent.

Out of scope:

- Proving live signed-in Android behavior. Connected visual/e2e remains not run locally because no device/emulator was available.
- Proving future rclone child visibility under `drive.file`; the explicit readonly link fallback exists for that recovery path.

## 10/10 Standard

Give `SCORE: 10/10`, `VERDICT: PASS`, and `VISUAL REVIEW: NOT APPLICABLE` only if:

- all R1 findings are closed,
- no new release-blocking behavior/privacy/evidence findings are present,
- the missing connected-device evidence is honestly documented and acceptable for this scoped source/release audit,
- package hygiene is sufficient for this review.
